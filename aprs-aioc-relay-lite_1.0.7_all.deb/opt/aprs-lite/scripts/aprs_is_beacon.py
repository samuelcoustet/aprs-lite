#!/usr/bin/env python3
import re, socket, sys
from datetime import datetime, timezone

CONF = "/opt/aprs-lite/direwolf.conf"
HOST = "euro.aprs2.net"
PORT = 14580
LAT = "4319.08N"
LON = "00019.89W"
COMMENT = "iGate/F6KDU"

def read_login(conf):
    mycall = None
    passcode = None
    with open(conf, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            m = re.match(r"^MYCALL\s+(\S+)", s, re.I)
            if m:
                mycall = m.group(1).split("-")[0]
            m = re.match(r"^IGLOGIN\s+(\S+)\s+(\S+)", s, re.I)
            if m:
                passcode = m.group(2)
                if mycall is None:
                    mycall = m.group(1).split("-")[0]
    if not mycall or not passcode:
        raise RuntimeError("MYCALL/IGLOGIN introuvable dans direwolf.conf")
    return mycall, passcode

def main():
    call, pwd = read_login(CONF)
    login = f"user {call} pass {pwd} vers aprs-is-beacon 1.0\n"
    packet = f"{call}>APDW17,TCPIP*:!{LAT}/{LON}# {COMMENT}\n"

    with socket.create_connection((HOST, PORT), timeout=15) as s:
        s.settimeout(15)
        s.sendall(login.encode("ascii", "ignore"))
        _ = s.recv(512)  # logresp
        s.sendall(packet.encode("ascii", "ignore"))

    now = datetime.now(timezone.utc).isoformat()
    print(f"{now} sent: {packet.strip()}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
